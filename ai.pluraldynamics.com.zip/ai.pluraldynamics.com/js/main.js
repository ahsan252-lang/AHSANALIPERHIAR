(function($) {
    "use strict";

    // Spinner
    var spinner = function() {
        setTimeout(function() {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner(0);


    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function() {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });


    // Hero Header carousel
    $(".header-carousel").owlCarousel({
        animateOut: 'slideOutDown',
        items: 1,
        autoplay: true,
        smartSpeed: 1000,
        dots: false,
        loop: true,
        nav: true,
        navText: [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
    });


    // International carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        items: 1,
        smartSpeed: 1500,
        dots: true,
        loop: true,
        margin: 25,
        nav: true,
        navText: [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ]
    });


    // Modal Video
    $(document).ready(function() {
        var $videoSrc;
        $('.btn-play').click(function() {
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function(e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function(e) {
            $("#video").attr('src', $videoSrc);
        })
    });


    // testimonial carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        dots: true,
        loop: true,
        margin: 25,
        nav: true,
        navText: [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsiveClass: true,
        responsive: {
            0: {
                items: 1
            },
            576: {
                items: 1
            },
            768: {
                items: 1
            },
            992: {
                items: 1
            },
            1200: {
                items: 1
            }
        }
    });



    // Get the button
    var backToTopButton = document.getElementById("backToTop");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            backToTopButton.style.display = "block";
        } else {
            backToTopButton.style.display = "none";
        }
    }

    // When the user clicks on the button, scroll to the top of the document
    backToTopButton.onclick = function() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }


})(jQuery);




'use strict';
const tabs = document.querySelectorAll('[data-id]');
const contents = document.querySelectorAll('[data-content]');
let id = 0;

tabs.forEach(function(tab) {
    tab.addEventListener('click', function() {
        tabs[id].classList.remove('activetab');
        tab.classList.add('activetab');
        id = tab.getAttribute('data-id');
        contents.forEach(function(box) {
            box.classList.add('hide');
            if (box.getAttribute('data-content') == id) {
                box.classList.remove('hide');
                box.classList.add('show');
            }
        });
    });
});





new WOW().init();

// Roadmap carousel
$(".roadmap-carousel").owlCarousel({
    autoplay: true,
    smartSpeed: 1000,
    margin: 25,
    loop: true,
    dots: false,
    nav: true,
    navText: ['<i class="bi bi-chevron-left"></i>', '<i class="bi bi-chevron-right"></i>'],
    responsive: {
        0: {
            items: 1,
        },
        576: {
            items: 2,
        },
        768: {
            items: 3,
        },
        992: {
            items: 4,
        },
        1200: {
            items: 5,
        },
    },
});



$(document).ready(function() {
    $(".counter").each(function() {
        $(this)
            .prop("Counter", 0)
            .animate({
                Counter: $(this).data("count"),
            }, {
                duration: 4000,
                easing: "swing",
                step: function(now) {
                    $(this).text(Math.ceil(now));
                },
            });
    });
});






$(".option").click(function() {
    $(".option").removeClass("active");
    $(this).addClass("active");
});




$(".email").on("change keyup paste", function() {
    if ($(this).val()) {
        $(".icon-paper-plane").addClass("next");
    } else {
        $(".icon-paper-plane").removeClass("next");
    }
});

$(".next-button").hover(function() {
    $(this).css("cursor", "pointer");
});

$(".next-button.email").click(function() {
    console.log("Something");
    $(".email-section").addClass("fold-up");
    $(".password-section").removeClass("folded");
});

$(".password").on("change keyup paste", function() {
    if ($(this).val()) {
        $(".icon-lock").addClass("next");
    } else {
        $(".icon-lock").removeClass("next");
    }
});

$(".next-button.password").click(function() {
    console.log("Something");
    $(".password-section").addClass("fold-up");
    $(".repeat-password-section").removeClass("folded");
});

$(".repeat-password").on("change keyup paste", function() {
    if ($(this).val()) {
        $(".icon-repeat-lock").addClass("next");
    } else {
        $(".icon-repeat-lock").removeClass("next");
    }
});

$(".next-button.repeat-password").click(function() {
    console.log("Something");
    $(".repeat-password-section").addClass("fold-up");
    $(".success").css("marginTop", 0);
});






$(".email").on("change keyup paste", function() {
    if ($(this).val()) {
        $(".icon-paper-plane").addClass("next");
    } else {
        $(".icon-paper-plane").removeClass("next");
    }
});

$(".next-button").hover(function() {
    $(this).css("cursor", "pointer");
});

$(".next-button.email").click(function() {
    console.log("Something");
    $(".email-section").addClass("fold-up");
    $(".password-section").removeClass("folded");
});

$(".password").on("change keyup paste", function() {
    if ($(this).val()) {
        $(".icon-lock").addClass("next");
    } else {
        $(".icon-lock").removeClass("next");
    }
});

$(".next-button.password").click(function() {
    console.log("Something");
    $(".password-section").addClass("fold-up");
    $(".repeat-password-section").removeClass("folded");
});

$(".repeat-password").on("change keyup paste", function() {
    if ($(this).val()) {
        $(".icon-repeat-lock").addClass("next");
    } else {
        $(".icon-repeat-lock").removeClass("next");
    }
});

$(".next-button.repeat-password").click(function() {
    console.log("Something");
    $(".repeat-password-section").addClass("fold-up");
    $(".success").css("marginTop", 0);
});